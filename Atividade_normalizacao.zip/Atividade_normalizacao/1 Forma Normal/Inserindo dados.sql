INSERT INTO DEPARTAMENTO (SIGLA, NOME, CHEFE, DEPARTAMENTO_SUPERIOR) VALUES
('RH', 'João da Silva', 'Leci Brandao', 'Diretoria'),
('RH', 'Maria Oliveira', 'Leci Brandao', 'Diretoria'),
('ADM', 'Leticia Albuquerque', 'Beth Carvalho', 'Recursos Humanos'),
('ADM', 'Pedro Souza', 'Beth Carvalho', 'Recursos Humanos'),
('MKT', 'Ana Santos', 'Clara Nunes', 'Vendas'),
('MKT', 'Ricardo Miranda', 'Clara Nunes', 'Vendas'),
('VND', 'Denis Barbosa', 'Elis Regina', 'Diretoria'),
('VND', 'Rita Fonseca', 'Elis Regina', 'Diretoria'),
('TRN', 'Carlos Ferreira', 'Norma Bengell', 'Recursos Humanos'),
('TRN', 'Mariana Lima', 'Norma Bengell', 'TRecursos Humanos');


INSERT INTO COLABORADOR (MATRICULA, CPF, NOME, SALARIO, DEPARTAMENTO) VALUES
('RF001','31525889656', 'João da Silva', '4500', 'Recursos Humanos'),
('RF002','31523689656', 'Maria Oliveira', '4500', 'Recursos Humanos'),
('RF003','24823689624', 'Leticia Albuquerque', '3700', 'Administrativo'),
('RF004','24841589689', 'Pedro Souza', '3700', 'Administrativo'),
('RF005','24841589249', 'Ana Santos', '5200', 'Marketing'),
('RF006','12741589689', 'Ricardo Miranda', '5200', 'Marketing'),
('RF007','24825889612', 'Denis Barbosa', '7100', 'Vendas'),
('RF008','21586989637', 'Rita Fonseca', '7100', 'Vendas'),
('RF009','42058965874', 'Carlos Ferreira', '3200', 'Treinanmento'),
('RF010','58498712356', 'Mariana Lima', '3000', 'Treinanmento');


INSERT INTO COLABORADOR_CADASTRO (CPF, NOME, TELEFONE, EMAIL_PESSOAL, EMAIL_CORPORATIVO, ESTADO, CIDADE, BAIRRO, LOGRADOURO, COMPLEMENTO, CEP) VALUES
('31525889656', 'João da Silva', '(11)9876-5432', 'contato1@exemplo.com', 'contatojob1@exemplo.com', 'SP', 'São Paulo', 'Ponte Pequena', 'Rua um e dois', 'Apto 14', '08030110'),
('31523689656', 'Maria Oliveira', '(21)8765-4321', 'contato2@exemplo.com', 'contatojob2@exemplo.com', 'SP', 'São Paulo', 'Penha', 'Rua três e quatro', 'Casa', '08030140'),
('24823689624', 'Leticia Albuquerque', '(11)9876-5432', 'contato3@exemplo.com', 'contatojob3@exemplo.com', 'SP', 'São Paulo', 'Tatuapé', 'Rua cinco e seis', 'Casa', '06040140'),
('24841589689', 'Pedro Souza', '(11)5555-8888', 'contato4@exemplo.com', 'contatojob4@exemplo.com', 'SP', 'São Paulo', 'Limão', 'Rua sete e oito', 'Apto 24', '06030192'),
('24841589249', 'Ana Santos', '(11)9999-1111', 'contato5@exemplo.com', 'contatojob5@exemplo.com', 'SP', 'São Paulo', 'Mooca', 'Rua nove', 'Casa', '03030492'),
('12741589689', 'Ricardo Miranda', '(11)7777-4444', 'contato6@exemplo.com', 'contatojob6@exemplo.com', 'SP', 'São Paulo', 'Pinheiros', 'Rua dez', 'Casa', '10430415'),
('24825889612', 'Denis Barbosa', '(11)4412-6176', 'contato7@exemplo.com', 'contatojob7@exemplo.com', 'SP', 'São Paulo', 'Sacomã', 'Rua onze', 'Apto 69', '02425920'),
('21586989637', 'Rita Fonseca', '(11)9998-1251', 'contato8@exemplo.com', 'contatojob8@exemplo.com', 'SP', 'São Paulo', 'Perdizes', 'Rua doze', 'Apto 22', '03010420'),
('42058965874', 'Carlos Ferreira', '(11)9998-1251', 'contato9@exemplo.com', 'contatojob9@exemplo.com', 'SP', 'São Paulo', 'Joanisa', 'Rua treze', 'Apto 55', '03058620'),
('58498712356', 'Norma Bengell', '(11)5589-8954', 'contato10@exemplo.com', 'contatojob10@exemplo.com', 'SP', 'São Paulo', 'Itaquera', 'Rua quatorze', 'Casa', '01258620');


INSERT INTO DEPENDENTE (CPF, COLABORADOR, NOME, DATA_NASCIMENTO, PARENTESCO) VALUES
('31588748145', 'COL001', 'Junior da Silva', '2020-02-05', 'Filho'),
('34855554234', 'COL001', 'Felipe da Silva', '2019-05-14', 'Filho'),
('55849523554', 'COL005', 'Rodolfo Marinho Santos', '1956-07-11', 'Conjuge'),
('12584759344', 'COL005', 'Mariana Marinho Santos', '2027-04-12', 'Filha');


INSERT INTO PROJETO (ID, NOME, RESPONSAVEL, INICIO, FIM) VALUES
('PROJ001', 'João da Silva', 'Leci Brandao', '2024-01-05', '2024-07-05'),
('PROJ001', 'Leticia Albuquerque', 'Beth Carvalho', '2024-01-05', '2024-07-05'),
('PROJ001', 'Ana Santos', 'Clara Nunes', '2024-01-05', '2024-07-05'),
('PROJ001', 'Denis Barbosa', 'Elis Regina', '2024-01-05', '2024-07-05'),
('PROJ001', 'Carlos Ferreira', 'Norma Bengell', '2024-01-05', '2024-07-05'),
('PROJ002', 'Maria Oliveira', 'Leci Brandao', '2024-03-05', '2024-10-05'),
('PROJ002', 'Pedro Souza', 'Beth Carvalho', '2024-03-05', '2024-10-05'),
('PROJ002', 'Ricardo Miranda', 'Clara Nunes', '2024-03-05', '2024-10-05'),
('PROJ002', 'Rita Fonseca', 'Elis Regina', '2024-03-05', '2024-10-05'),
('PROJ002', 'Mariana Lima', 'Norma Bengell', '2024-03-05', '2024-10-05');


INSERT INTO ATRIBUICAO (COLABORADOR, PROJETO, PAPEL) VALUES
('COL001','PROJ001', 'Conteudo'),
('COL002','PROJ002', 'Conteudo'),
('COL003','PROJ001', 'Orçamento'),
('COL004','PROJ002', 'Orçamento'),
('COL005','PROJ001', 'Programacao'),
('COL006','PROJ002', 'Programacao'),
('COL007','PROJ001', 'Divulgacao'),
('COL008','PROJ002', 'Divulgacao'),
('COL009','PROJ001', 'Analytics'),
('COL010','PROJ002', 'Dnalytics');

INSERT INTO PAPEL (ID, NOME) VALUES
('ID001', 'João da Silva'),
('ID002', 'Maria Oliveira'),
('ID003', 'Leticia Albuquerque'),
('ID004', 'Pedro Souza'),
('ID005', 'Ana Santos'),
('ID006', 'Ricardo Miranda'),
('ID007', 'Denis Barbosa'),
('ID008', 'Rita Fonseca'),
('ID009', 'Carlos Ferreira'),
('ID010', 'Mariana Lima');