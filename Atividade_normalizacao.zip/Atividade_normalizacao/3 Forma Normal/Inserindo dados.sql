INSERT INTO DEPARTAMENTO (SIGLA, NOME, CHEFE, DEPARTAMENTO_SUPERIOR) VALUES
('RH', 'João da Silva', 'Leci Brandao', 'Diretoria'),
('RH', 'Maria Oliveira', 'Leci Brandao', 'Diretoria'),
('ADM', 'Leticia Albuquerque', 'Beth Carvalho', 'Recursos Humanos'),
('ADM', 'Pedro Souza', 'Beth Carvalho', 'Recursos Humanos'),
('MKT', 'Ana Santos', 'Clara Nunes', 'Vendas'),
('MKT', 'Ricardo Miranda', 'Clara Nunes', 'Vendas'),
('VND', 'Denis Barbosa', 'Elis Regina', 'Diretoria'),
('VND', 'Rita Fonseca', 'Elis Regina', 'Diretoria'),
('TRN', 'Carlos Ferreira', 'Norma Bengell', 'Recursos Humanos'),
('TRN', 'Mariana Lima', 'Norma Bengell', 'TRecursos Humanos');


INSERT INTO COLABORADOR (MATRICULA, CPF, NOME, SALARIO, DEPARTAMENTO) VALUES
('RF001','31525889656', 'João da Silva', '4500', 'Recursos Humanos'),
('RF002','31523689656', 'Maria Oliveira', '4500', 'Recursos Humanos'),
('RF003','24823689624', 'Leticia Albuquerque', '3700', 'Administrativo'),
('RF004','24841589689', 'Pedro Souza', '3700', 'Administrativo'),
('RF005','24841589249', 'Ana Santos', '5200', 'Marketing'),
('RF006','12741589689', 'Ricardo Miranda', '5200', 'Marketing'),
('RF007','24825889612', 'Denis Barbosa', '7100', 'Vendas'),
('RF008','21586989637', 'Rita Fonseca', '7100', 'Vendas'),
('RF009','42058965874', 'Carlos Ferreira', '3200', 'Treinanmento'),
('RF010','58498712356', 'Mariana Lima', '3000', 'Treinanmento');


INSERT INTO COLABORADOR_CADASTRO (CPF, NOME, TELEFONE, EMAIL_PESSOAL, EMAIL_CORPORATIVO, ESTADO, CIDADE, BAIRRO, LOGRADOURO, COMPLEMENTO, CEP) VALUES
('31525889656', 'João da Silva', '(11)9876-5432', 'contato1@exemplo.com', 'contatojob1@exemplo.com', 'SP', 'São Paulo', 'Ponte Pequena', 'Rua um e dois', 'Apto 14', '08030110'),
('31523689656', 'Maria Oliveira', '(21)8765-4321', 'contato2@exemplo.com', 'contatojob2@exemplo.com', 'SP', 'São Paulo', 'Penha', 'Rua três e quatro', 'Casa', '08030140'),
('24823689624', 'Leticia Albuquerque', '(11)9876-5432', 'contato3@exemplo.com', 'contatojob3@exemplo.com', 'SP', 'São Paulo', 'Tatuapé', 'Rua cinco e seis', 'Casa', '06040140'),
('24841589689', 'Pedro Souza', '(11)5555-8888', 'contato4@exemplo.com', 'contatojob4@exemplo.com', 'SP', 'São Paulo', 'Limão', 'Rua sete e oito', 'Apto 24', '06030192'),
('24841589249', 'Ana Santos', '(11)9999-1111', 'contato5@exemplo.com', 'contatojob5@exemplo.com', 'SP', 'São Paulo', 'Mooca', 'Rua nove', 'Casa', '03030492'),
('12741589689', 'Ricardo Miranda', '(11)7777-4444', 'contato6@exemplo.com', 'contatojob6@exemplo.com', 'SP', 'São Paulo', 'Pinheiros', 'Rua dez', 'Casa', '10430415'),
('24825889612', 'Denis Barbosa', '(11)4412-6176', 'contato7@exemplo.com', 'contatojob7@exemplo.com', 'SP', 'São Paulo', 'Sacomã', 'Rua onze', 'Apto 69', '02425920'),
('21586989637', 'Rita Fonseca', '(11)9998-1251', 'contato8@exemplo.com', 'contatojob8@exemplo.com', 'SP', 'São Paulo', 'Perdizes', 'Rua doze', 'Apto 22', '03010420'),
('42058965874', 'Carlos Ferreira', '(11)9998-1251', 'contato9@exemplo.com', 'contatojob9@exemplo.com', 'SP', 'São Paulo', 'Joanisa', 'Rua treze', 'Apto 55', '03058620'),
('58498712356', 'Norma Bengell', '(11)5589-8954', 'contato10@exemplo.com', 'contatojob10@exemplo.com', 'SP', 'São Paulo', 'Itaquera', 'Rua quatorze', 'Casa', '01258620');


INSERT INTO DEPENDENTE (CPF_DEP, COLABORADOR, NOME, DATA_NASCIMENTO, PARENTESCO) VALUES
('31588748145', 'COL001', 'Junior da Silva', '2020-02-05', 'Filho'),
('34855554234', 'COL001', 'Felipe da Silva', '2019-05-14', 'Filho'),
('55849523554', 'COL005', 'Rodolfo Marinho Santos', '1956-07-11', 'Conjuge'),
('12584759344', 'COL005', 'Mariana Marinho Santos', '2027-04-12', 'Filha');


INSERT INTO PROJETO (ID, NOME_PROJETO, RESPONSAVEL, INICIO, FIM, STATUS) VALUES
('PROJ001', 'Projeto Revitalização', 'Leci Brandao', '2024-01-05', '2024-07-05', 'Em andamento'),
('PROJ002', 'Projeto Inovação 2024', 'Clara Nunes', '2024-03-05', '2024-10-05', 'A iniciar');


INSERT INTO COLABORADORES_PROJETO (COLABORADOR, NOME_PROJETO, ID, PAPEL) VALUES
('COL001', 'Projeto Revitalização', 'PROJ001', 'Conteudo'),
('COL002', 'Projeto Inovação 2024', 'PROJ002', 'Conteudo'),
('COL003', 'Projeto Revitalização', 'PROJ001', 'Orçamento'),
('COL004', 'Projeto Inovação 2024', 'PROJ002', 'Orçamento'),
('COL005', 'Projeto Revitalização', 'PROJ001', 'Programacao'),
('COL006', 'Projeto Inovação 2024', 'PROJ002', 'Programacao'),
('COL007', 'Projeto Revitalização', 'PROJ001', 'Divulgacao'),
('COL008', 'Projeto Inovação 2024', 'PROJ002', 'Divulgacao'),
('COL009', 'Projeto Revitalização', 'PROJ001', 'Analytics'),
('COL010', 'Projeto Inovação 2024', 'PROJ002', 'Analytics');


INSERT INTO COLABORADOR_PROJETO_FUNCAO (COLABORADOR, FUNCAO, ID, INICIO_FUNCAO, STATUS_FUNCAO) VALUES
('COL001', 'Conteudista', 'PROJ001', '2024-01-05', 'Atuando'),
('COL001', 'Programador', 'PROJ002', '2024-03-05', 'Aguardando início'),
('COL002', 'Conteudista', 'PROJ002', '2024-03-05', 'Aguardando início'),
('COL003', 'Orçamentista', 'PROJ001', '2024-01-05', 'Atuando'),
('COL004', 'Orçamentista', 'PROJ002', '2024-03-05', 'Aguardando início'),
('COL005', 'Programador', 'PROJ001', '2024-01-05', 'Atuando'),
('COL006', 'Programador', 'PROJ002', '2024-03-05', 'Aguardando início'),
('COL007', 'Social Media', 'PROJ001', '2024-01-05', 'Atuando'),
('COL007', 'Designer Gráfico', 'PROJ002', '2024-03-05', 'Aguardando início'),
('COL008', 'Analytics', 'PROJ002', '2024-03-05', 'Aguardando início'),
('COL009', 'Analytics', 'PROJ001', '2024-01-05', 'Atuando'),
('COL009', 'Roteirista', 'PROJ002', '2024-03-05', 'Aguardando início'),
('COL010', 'Analytics', 'PROJ002', '2024-03-05', 'Aguardando início');